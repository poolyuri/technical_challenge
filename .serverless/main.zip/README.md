<p align="center">
  <a href="http://nestjs.com/" target="blank"><img src="https://nestjs.com/img/logo-small.svg" width="120" alt="Nest Logo" /></a>
</p>

# <center>**Backend NestJS/AWS | Challenge**</center>

## 1. Instalación de componentes globales

### 1.1. AWS CLI
Instala el [**AWS CLI**](https://aws.amazon.com/es/cli/) en tu computadora y configura el entorno con el siguiente comando:

```bash
aws config
```

Tienes que ingresar los datos propocionados por AWS
```bash
aws_access_key_id=<TODO>
aws_secret_access_key=<TODO>
```

### 1.2. Instalar Serverless
Si no tienes instalado Serverless, se recomienda hacer la instalación de forma global con el siguiente comando:

```bash
npm i -g serverless
```

### 1.3. Instalar NestJS
Se recomienda instalar NestJS de forma global con el siguiente comando:

```bash
npm i -g @nestjs/cli
```

## 2. Instalación de dependencias externas

### 2.1 Instalar Redis
Instala [**Redis para Windows**](https://redis.io/docs/latest/operate/oss_and_stack/install/install-redis/install-redis-on-windows/) en tu computadora siguiendo los pasos que recomienda su pagina oficial.

### 2.2 Iniciar Redis desde Ubuntu
Si no se ha instalado el WSL (Windows Subsystem for Linux), se recomienda seguir los pasos de instalación del siguiente enlace que proporciona [**Windows**](https://learn.microsoft.com/en-us/windows/wsl/install).

Una ves que se tenga iniciado el WSL de Ubuntu, ejecutar el siguiente comando:

```bash
# iniciar redis
sudo service redis-server start

# parar redist
sudo service redis-server stop
```

Para validar que efectivamente Redis este ejecutandose correctamente ejecutamos el siguiente comando:

```bash
redis-cli
```

Validmos escribiendo la palabra <code>**ping**</code> en la consola y nos tiene que retornar la palabra <code>**PONG**</code>

Ejemplo:

![Redis](/images/1_redis_command.png)

### 2.3 Instala Docker Desktop
En mi caso, estoy trabajando con [**Docker Desktop**](https://docs.docker.com/desktop/setup/install/windows-install/), otra opción seria usar [**Podman**](https://podman.io/get-started)

### 2.4 Configuración de archivo YML
Dado que es necesario tener Redis iniciado dentro del contenedor de Docker, estoy usando este archivo YML.

```yml
services:
  redis:
    container_name: redis
    image: redis:7.4.2
    ports:
      - "6379:6379"
    volumes:
      - redis:/data

volumes:
  redis:
```

Tenemos que iniciar el contenedor de redis con el siguiente comando
```bash
docker-compose up -d redis
```

Para detener el contenedor, ejecutar el siguiente comando
```bash
docker-compose stop redis
```

Ejemplo:

![Redis](/images/2_redis_docker.png)

## 3. Iniciar proyecto

### 3.1 Instalación
Instalar los paquetes, módulos y librerias necesarias para ejecutar el proyecto

```bash
$ npm install
```

### 3.2 Compilar y ejecutar el proyecto

```bash
# watch mode
$ npm run start:dev

# production mode
$ npm run start:prod
```

### 3.3 Ejecutar test unitarios y convergencia

```bash
# unit tests
$ npm run test:watch

# test coverage
$ npm run test:cov
```

## 4. Descripción del reto técnico

### 4.1 Pruebas unitarias

**Unit Test**

![Instalación](/images/3_unit_test.png)

**Coverage Test**

![Instalación](/images/4_cov_test.png)

### 4.2 Uso de TypeScript
Este proyecto esta construido con TypeScript, dado que NestJS es totalmente compatible.

### 4.3 Se generaron 3 enpoints
A continuación se detallan las rutas de los 3 endpoints:

#### 4.3.1 Fusion
Obtiene los datos fusinados de las apis externas

```
http://localhost:3000/customs/fusion/5
```

#### 4.3.2 Resources
Guarda datos propios de la base de datos
```
http://localhost:3000/customs/resources
```

#### 4.3.2 History
Obtiene el historial de consultas por pagina y limite, ordenado por fecha
```
http://localhost:3000/customs/history?page=1&limit=10
```

### 4.4 Cacheo de resultados
Se esta usando Redis y la libreria <code>@keyv/redis</code> para el cacheo de resultados, configurando un intervalo de 30 minutos

#### 4.4.1 Configuración

Configuración de variables de entorno
```env
REDIS_URL=127.0.0.1
REDIS_PORT=6379
REDIS_TTL=30m
```

En <code>\infrastructure\config\enviroment.config.ts</code> agregamos
```typescript
  redis: {
    url: process.env.REDIS_URL,
    port: process.env.REDIS_PORT,
    ttl: process.env.REDIS_TTL
  }
```

En <code>\infrastructure\common\strategies\enviroment.strategy.ts</code> implementamos <code>RedisConfig.ts</code>
```typescript
  getRedisUrl(): string {
    return this.configService.get<string>('redis.url') || '';
  }

  getRedisPort(): number {
    return this.configService.get<number>('redis.port') || 6379;
  }

  getRedisTtl(): string {
    return this.configService.get<string>('redis.ttl') || '30m';
  }
```

Creamos el modulo <code>redis.module</code> dentro de <code>\infrastructure\config</code>
```typescript
import { Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Cacheable } from 'cacheable';
import KeyvRedis from '@keyv/redis';
import { EnviromentConfigModule } from './enviroment.module';
import { CACHE_INSTANCE } from '@core';
import { RedisService } from '@infrastructure/services/redis/redis.service';
import { EnviromentStrategy } from '@infrastructure/common/strategies/enviroment.strategy';

@Module({
  imports: [EnviromentConfigModule],
  providers: [
    {
      provide: CACHE_INSTANCE,
      inject: [EnviromentStrategy, ConfigService],
      useFactory: async (config: EnviromentStrategy) => {
        const redisUrl = `redis://${config.getRedisUrl()}:${config.getRedisPort()}`;
        const secondary = new KeyvRedis(redisUrl);
        return new Cacheable({ secondary, ttl: config.getRedisTtl() });
      },
    },
    RedisService,
  ],
  exports: [CACHE_INSTANCE, RedisService],
})
export class RedisModule {}
```

### 4.5 Despliegue en AWS usando Serverless

#### 4.4.1 Despliegue offline
Para hacer pruebas antes del pliegue a AWS, en mi caso estoy validando de manera fuera de linea (offline) con el siguiente comando

```bash
serverless offline
```

**Coverage Test**

![Instalación](/images/5_serverless_offline.png)

#### 4.4.1 Despliegue en AWS
Ejecutamos el despliegue en AWS con el siguiente comando

```bash
serverless deploy
```