export interface ThorttleConfig {
  getThorttleTtl(): number;
  getThorttleLimit(): number;
}
