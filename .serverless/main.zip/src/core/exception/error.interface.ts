export interface IErrorResponse {
  message?: string;
  code_error?: string | null;
}