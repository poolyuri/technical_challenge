export interface People {
  name: string,
  gender: string
  homeworld: string,
  birth_year: string
}