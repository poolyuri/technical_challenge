export interface Planet {
  name: string,
  climate: string,
  rotation_period: number,
  orbital_period: number
}